@extends('layouts.master')

@section('content')
<h1>Tous les vêtements</h1>
{{$products->links()}}
<ul class="list-group">
@forelse($products as $product)
<li class="list-group-item">
<h2><a href="{{url('product', $product->id)}}">{{$product->title}}</a></h2>
<div class="row">
@if(is_null($product->picture) === false)
<!-- {{$product->picture->link}} -->
        <div class="col-xs-6 col-md-3">
            <a href="#" class="thumbnail">
            <img width="171" src="{{asset('images/'.$product->picture->link)}}" alt="{{$product->picture->title}}">
            </a>
        </div>
@endif
<div class="col-xs-6 col-md-9">
{{$product->description}}
</div>
</div>

@empty
<li>Désolé pour l'instant aucun vêtement n'est disponible sur le site</li>
@endforelse
</ul>
{{$products->links()}}
@endsection 