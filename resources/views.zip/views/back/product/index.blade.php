@extends('layouts.master')

@section('content')
<p><a href="{{route('product.create')}}"><button type="button" class="btn btn-primary btn-lg">Ajouter un vêtement</button></a></p>
@include('back.product.partials.flash')
{{$products->links()}}
    <table class="table">
        <tr>
            <th>Title</th>
            <th>Authors</th>
            <th>Genre</th>
            <th>Date de publication</th>
            <th>Status</th>
            <th>Edition</th>
            <th>Show</th>
            <th>Delete</th>
        </tr>

        @forelse($products as $product)
        <tr>
            <td>{{$product->title}}</td>

            <td>
            @forelse($product->authors as $author)
                {{$author->name}}
            @empty
            Aucun auteur
            @endforelse
            </td>

            <td>{{$product->genre->name}}</td>

            <td>{{$product->published_at}}</td>

            <td>Status TODO</td>

            <td><a href="{{route('product.edit', $product->id)}}"><i class="fas fa-pen-square"></i></a></td>

            <td><a href="{{route('product.show', $product->id)}}"><i class="far fa-eye"></i></a></td>
            <td>DELETE</td>
        @empty
            <td>Aucun livre</td>
        @endforelse
        </tr>
    </table>
@endsection