<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand text-muted" href="#">{{config('app.name')}}</a>
  <a class="nav-link text-muted active" href="{{url('/')}}">Accueil</a>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      @if(Route::is('product.*') == false)
      @forelse($categories as $id => $name)
      <li class="nav-item"><a class="nav-link text-muted active" href="{{url('genre', $id)}}">{{$name}}</a></span>
        @empty
      <li>Aucune catégorie pour l'instant</li>
      @endforelse
      @endif
    </ul>

  </div>
</nav>